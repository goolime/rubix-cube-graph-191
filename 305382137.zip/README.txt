Gal Meir - 305382137
I have implemented only the basic functions (no bonuses)
Commands implemented:
	'R' press state for right wall rotation (90 degrees clockwise). 
	'L' press state for right wall rotation (90 degrees clockwise). 
	'U' press state for up wall rotation (90 degrees clockwise). 
	'D' press state for down wall rotation (90 degrees clockwise). 
	'B' press state for back wall rotation (90 degrees clockwise). 
	'F' press state for front wall rotation (90 degrees clockwise). 
	'  ' press state for flipping rotation direction (from clockwise to counter clockwise or vise versa). 
	'Z' press state: dividing rotation angle by 2.
	'A' press state: multiply rotation angle by 2 (until maximum of 180).
	All mouse movement as required

Added functions (done for testing):
	'C' restarts the position of the cube on the screen
	'X' restarts the cube alignment (doesn't solve the cube!) and the rotation angle to 90 degrees
	Left and Right arrows � rotation around the Y axis
	Up and Down arrows � rotation around the X axis
